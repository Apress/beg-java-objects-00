// Calculator3B.java - Chapter 16 example.

// Copyright 2000 by Jacquie Barker - all rights reserved.

import java.awt.*;
import javax.swing.*;
import java.awt.event.*; // added for event handling

public class Calculator3B extends JFrame {
	// Components are treated as attributes, so that they will be
	// visible to all of the methods of the class.

	private Container contentPane;

	// Use descriptive names for components where possible; it makes
	// your job easier later on!

	private JPanel leftPanel; 
	private JPanel centerPanel; 
	private JPanel buttonPanel; 
	private JTextField input1TextField; 
	private JTextField input2TextField; 
	private JLabel answerLabel; 
	private JButton plusButton; 
	private JButton minusButton; 

	// Constructor.
	public Calculator3B() {	
		// Invoke the generic JFrame constructor.
		super("Simple Calculator");

		// The content pane container is now declared to be an
		// attribute.  Note that the use of "this." is unnecessary;
		// we could have simply written:
		// contentPane = getContentPane();
		contentPane = this.getContentPane();
		this.setSize(250, 100);

		// Technique for centering a frame on the screen.
		Dimension frameSize = this.getSize();
		Dimension screenSize = Toolkit.getDefaultToolkit().getScreenSize();
		this.setLocation((screenSize.width - frameSize.width)/2, 
			             (screenSize.height - frameSize.height)/2);

		leftPanel = new JPanel();
		leftPanel.setLayout(new GridLayout(3, 1));
		leftPanel.add(new JLabel("Input 1:  "));
		leftPanel.add(new JLabel("Input 2:  "));
		leftPanel.add(new JLabel("Answer:  "));
		contentPane.add(leftPanel, BorderLayout.WEST);

		centerPanel = new JPanel();
		centerPanel.setLayout(new GridLayout(3, 1));
		input1TextField = new JTextField(10);
		input2TextField = new JTextField(10);
		answerLabel = new JLabel();
		centerPanel.add(input1TextField);
		centerPanel.add(input2TextField);
		centerPanel.add(answerLabel);
		contentPane.add(centerPanel, BorderLayout.CENTER);

		buttonPanel = new JPanel();
		buttonPanel.setLayout(new GridLayout(2, 1));
		plusButton = new JButton("+");
		minusButton = new JButton("-");
		buttonPanel.add(plusButton);
		buttonPanel.add(minusButton);
		contentPane.add(buttonPanel, BorderLayout.EAST);

		// Add behaviors!  Note the use of anonymous inner classes.

		// Create a listener object to respond to
		// the "plus" button and register it.

		PlusButtonListener pbl = new PlusButtonListener();
		plusButton.addActionListener(pbl);

		// We do the same for the minus button.

		MinusButtonListener mbl = new MinusButtonListener();
		minusButton.addActionListener(mbl);

	        // Extra step:  because the listeners are now external,
		// we have to give the listeners "handles" on the
		// Calculator3B object, so that they can talk to the
		// calculator.

		pbl.setListenedTo(this);
		mbl.setListenedTo(this);

		// We set the frame to be visible after adding the listeners,
		// as a bug in 1.2.2 occasionally makes a listener 
		// "disfunctional" if it is added after the frame is visible.

  		this.setVisible(true);
  	}

	// We're adding the next three methods for the sole purpose of
	// supporting external listener objects; since they are
	// external, they now need to go through a few extra hoops
	// to obtain handles on the components that are attributes
	// to the Calculator3B class.

	public JTextField getInput1TextField() {
		return input1TextField;
	}

	public JTextField getInput2TextField() {
		return input2TextField;
	}

	public JLabel getAnswerLabel() {
		return answerLabel;
	}

	public static void main(String[] args) {
		// Instantiate the calculator!

		Calculator3B calc = new Calculator3B();
	}
}

// Create two named OUTER classes.  (The fact that they are in
// this same .java file is immaterial to the example; they would
// work just the same if they were in files named
// PlusButtonListener.java and MinusButtonListener.java.)

// Because these classes are now outside the scope of the
// Calculator3B class, they can no longer automatically "see"
// the attributes of that class; i.e. the components on the
// GUI.  So, the code as originally written for the
// actionPerformed() methods (commented out below) WON'T COMPILE;
// we have to go through a few extra steps to give these
// classes a way to access the text fields and labels of the 
// Calculator3 class.

// This illustrates why we prefer to keep listeners internal to
// the class that "owns" the components to be listened to!

class PlusButtonListener implements ActionListener {
    // We add an attribute, to maintain a handle on
    // the Calculator3 reference that we'll be handed.

    Calculator3B listenedTo;

    // Here's an extra method, added to facilitate 
    // getting a handle on the components of Calculator3.

    public void setListenedTo(Calculator3B c) {
	listenedTo = c;
    }

    public void actionPerformed(ActionEvent e) {
	/* COMMENT THIS OUT, BECAUSE IT WON'T COMPILE ...
	double d1 = 
	    new Double(input1TextField.getText()).doubleValue(); 
	double d2 = 
	    new Double(input2TextField.getText()).doubleValue(); 
	answerLabel.setText("" + (d1 + d2));
	*/

        // Repaired code:

	double d1 = 
	    new Double(listenedTo.getInput1TextField().getText()).doubleValue(); 
	double d2 = 
	    new Double(listenedTo.getInput2TextField().getText()).doubleValue(); 
	listenedTo.getAnswerLabel().setText("" + (d1 + d2));

    }
}

class MinusButtonListener implements ActionListener {
    // We add an attribute, to maintain a handle on
    // the Calculator3 reference that we'll be handed.

    Calculator3B listenedTo;

    // Here's an extra method, added to facilitate 
    // getting a handle on the components of Calculator3.

    public void setListenedTo(Calculator3B c) {
	listenedTo = c;
    }

    public void actionPerformed(ActionEvent e) {
	/* COMMENT THIS OUT, BECAUSE IT WON'T COMPILE ...
	double d1 = 
	    new Double(input1TextField.getText()).doubleValue(); 
	double d2 = 
	    new Double(input2TextField.getText()).doubleValue(); 
	answerLabel.setText("" + (d1 - d2));
	*/

        // Repaired code:

	double d1 = 
	    new Double(listenedTo.getInput1TextField().getText()).doubleValue(); 
	double d2 = 
	    new Double(listenedTo.getInput2TextField().getText()).doubleValue(); 
	listenedTo.getAnswerLabel().setText("" + (d1 - d2));

    }
}

