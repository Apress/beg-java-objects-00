// JListDemo3C.java - Chapter 16 example.

// Copyright 2000 by Jacquie Barker - all rights reserved.

import java.util.*;
import java.awt.*;
import javax.swing.*;
import javax.swing.event.*; // added

public class JListDemo3C {
	// By placing the declaration of the JList here, as an attribute
	// of the class as a whole, we avoid problems with accessing it
	// from within the inner ListSelectionListener class below.
	// We must declare it to be static, however, so that the main()
	// method, which is static, can "see" it.
	static JList myList;

	public static void main(String[] args) {
		JFrame theFrame = new JFrame("Sample JList");
		Container contentPane = theFrame.getContentPane();

		// Create a vector of students.

		Vector v = new Vector(); // of Students
		v.add(new Student("123456789", "Joe Blow"));
		v.add(new Student("987654321", "Fred Schnurd"));
		v.add(new Student("000000000", "Englebert Humperdink"));

		// Create a list based on this vector.  (By having
		// made myList an attribute of the JListDemo3C.
		// class as a whole, we avoid messing around with "final"
		// variable declarations.
		//? final JList myList = new JList(v);
		myList = new JList(v);
		contentPane.add(myList);

		// Add a listener to note when an item has been selected.

		ListSelectionListener lsl = new ListSelectionListener() {
			public void valueChanged(ListSelectionEvent e) {
				// When an item is selected (clicked!) in this 
				// list, display it at the command line.

				// To eliminate the "double display"
				// of this message, perform an initial
				// test.
				if (!myList.getValueIsAdjusting()) {
					Student s = (Student) 
						    myList.getSelectedValue();
				        System.out.println("Selected " + 
							   s.getName());
				}
			}
		};

		myList.addListSelectionListener(lsl);

	       	theFrame.setSize(300, 90);  // width, height
	       	theFrame.setVisible(true);
	}
}
