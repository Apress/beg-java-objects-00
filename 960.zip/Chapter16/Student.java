// Student.java - Chapter 16 example.

// Copyright 2000 by Jacquie Barker - all rights reserved.

// * * * * * * * * * * * * * * * * * * * * * * * * * * * *
// THIS IS AN ABBREVIATED VERSION OF THE Student CLASS,
// FOR USE WITH THE VARIOUS VERSIONS OF JListDemo.
// * * * * * * * * * * * * * * * * * * * * * * * * * * * *


import java.util.*;

public class Student {
	//------------
	// Attributes.
	//------------

	private String name;
	private String ssn;
	
	//----------------
	// Constructor(s).
	//----------------

	public Student(String ssn, String name) {
		this.ssn = ssn;
		this.name = name;
	}
	
	public String toString() {
		return name + " (" + ssn + ")"; 
	}

	public String getName() {
		return name;
	}
}
