// JListDemo.java - Chapter 16 example.

// Copyright 2000 by Jacquie Barker - all rights reserved.

import java.util.*;
import javax.swing.*;
import java.awt.*;

public class JListDemo {
	public static void main(String[] args) {
		JFrame theFrame = new JFrame("Sample JList");
		Container contentPane = theFrame.getContentPane( );

		// Create a vector of students.

		Vector v = new Vector(); // of Students
		v.add(new Student("123456789", "Joe Blow"));
		v.add(new Student("987654321", "Fred Schnurd"));
		v.add(new Student("000000000", "Englebert Humperdink"));

		// Create a list based on this vector.  The reason that
		// we can do this is because the Student class inherits
		// a toString() method from its parent Person class;
		// the method is defined as follows:
		/*
			public String toString() {
				return name + " (" + ssn + ")"; 
			}
		*/
		// which causes each Student object to be rendered
		// in terms of its name and SSN in the list.

		JList myList = new JList(v);
		contentPane.add(myList);

	       	theFrame.setSize(300, 90);  // width, height
	       	theFrame.setVisible(true);
	}
}
