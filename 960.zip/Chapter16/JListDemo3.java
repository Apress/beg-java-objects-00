// JListDemo3.java - Chapter 16 example.

// Copyright 2000 by Jacquie Barker - all rights reserved.

import java.util.*;
import java.awt.*;
import javax.swing.*;
import javax.swing.event.*; // added

public class JListDemo3 {
	public static void main(String[] args) {
		JFrame theFrame = new JFrame("Sample JList");
		Container contentPane = theFrame.getContentPane();

		// Create a vector of students.

		Vector v = new Vector(); // of Students
		v.add(new Student("123456789", "Joe Blow"));
		v.add(new Student("987654321", "Fred Schnurd"));
		v.add(new Student("000000000", "Englebert Humperdink"));

		// Create a list based on this vector.  (We must declare
		// myList to be a final variable; otherwise, the compiler
		// will complain when we try to access it from the inner
		// class that we create as a listener below.)

		final JList myList = new JList(v);
		contentPane.add(myList);

		// Add a listener to note when an item has been selected.

		ListSelectionListener lsl = new ListSelectionListener() {
			public void valueChanged(ListSelectionEvent e) {
				// When an item is selected (clicked!) in this 
				// list, display it at the command line.

				Student s = (Student) myList.getSelectedValue();
				System.out.println("Selected " + s.getName());
			}
		};

		myList.addListSelectionListener(lsl);

	       	theFrame.setSize(300, 90);  // width, height
	       	theFrame.setVisible(true);
	}
}
