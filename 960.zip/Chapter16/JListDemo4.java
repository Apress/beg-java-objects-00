// JListDemo4.java - Chapter 16 example.

// Copyright 2000 by Jacquie Barker - all rights reserved.

import java.util.*;
import java.awt.*;
import javax.swing.*;
import java.awt.event.*; // added

public class JListDemo4 {
	public static void main(String[] args) {
		JFrame theFrame = new JFrame("Sample JList");
		Container contentPane = theFrame.getContentPane();

		// Create a vector of students.

		Vector v = new Vector(); // of Students
		v.add(new Student("123456789", "Joe Blow"));
		v.add(new Student("987654321", "Fred Schnurd"));
		v.add(new Student("000000000", "Englebert Humperdink"));

		// Create a list based on this vector.  (We must declare
		// myList to be a final variable; otherwise, the compiler
		// will complain when we try to access it from the inner
		// class that we create as a listener below.)

		final JList myList = new JList(v);
		contentPane.add(myList, BorderLayout.CENTER);

		// Create a button that will pull the selected entry
		// from the list when the button is clicked.

		JButton selectButton = new JButton("Select");
		contentPane.add(selectButton, BorderLayout.SOUTH);

		// Add a listener to the button.

		ActionListener listener = new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				Student s = (Student) myList.getSelectedValue();
				System.out.println("Selected " + s.getName());
			}
		};

		selectButton.addActionListener(listener);

	       	theFrame.setSize(300, 120);  // width, height
	       	theFrame.setVisible(true);
	}
}
