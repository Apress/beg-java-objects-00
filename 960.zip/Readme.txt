In Appendix D of Beginning Java Objects, the instructions for downloading 
the SRS source code talk about a file named "code.jar".  Instead, the code
for the Student Registration System example in chapters 14 - 16 are being
provided as a "zipped" file named "1590591461-1.zip" instead.  Please 
disregard all of the instructions concerning jar files on page 631 of the 
book.  Note that the directory diagram on page 632 is correct, however, as 
are the instructions that follow the diagram.

When you unzip 1590591461-1.zip, make sure to specify that you want to 
"Use Directory Names from Zip File" with whatever zip utility you are 
using.


