// SRS.java - Chapter 15 version.

// Copyright 2000 by Jacquie Barker - all rights reserved.

// A main driver for the command-line driven version of the SRS, with
// file persistence added.


import java.util.*;

public class SRS {
	// We can effectively create "global" data by declaring
	// PUBLIC STATIC attributes in the main class.  

	// Entry points/"roots" for getting at objects.  

	public static Faculty faculty = new Faculty();

	public static CourseCatalog courseCatalog = new CourseCatalog(); 

	public static ScheduleOfClasses scheduleOfClasses = 
		      new ScheduleOfClasses("SP2001");

	// We don't create a collection for Student objects, because
	// we're only going to handle one Student at a time -- namely,
	// whichever Student is logged on.
	//? public static StudentBody studentBody = new StudentBody();

	public static void main(String[] args) {
		// Initialize the key objects by reading data from files.
		// Setting the second argument to true causes the
		// initializeObjects() method to use the parseData()
		// method instead of parseData2().

		faculty.initializeObjects("Faculty.dat", true);
		courseCatalog.initializeObjects("CourseCatalog.dat", true);
		scheduleOfClasses.initializeObjects("SoC_SP2001.dat", true);

		// We'll handle the students differently:  that is,
		// rather than loading them all in at application outset,
		// we'll pull in the data that we need just for one
		// Student when that Student logs on -- see the Student
		// class constructor for the details.

		// Let's temporarily create Students this way as a test,
		// to simulate Students logging on.  Note that only the
		// first Student has "preregistered" for courses based
		// on the content of his/her ssn.dat file (see Student.java
		// for details).

		Student s1 = new Student("111-11-1111");
		Student s2 = new Student("222-22-2222");
		Student s3 = new Student("333-33-3333");

		// Establish some prerequisites (c1 => c2 => c3 => c4).
		// Setting the second argument to false causes the
		// initializeObjects() method to use the parseData2()
		// method instead of parseData().

		courseCatalog.initializeObjects("Prerequisites.dat", false);

		// Recruit a professor to teach each of the sections.
		// Setting the second argument to false causes the
		// initializeObjects() method to use the parseData2()
		// method instead of parseData().

		faculty.initializeObjects("TeachingAssignments.dat", false);

		// Let's have one Student try enrolling in something, so
		// that we can simulate his/her logging off and persisting
		// the enrollment data in the ssn.dat file (see Student.java
		// for details).

		Section sec = scheduleOfClasses.findSection("ART101 - 1");
		sec.enroll(s2);
		s2.persist();  // Check contents of 222-22-2222.dat!

		// Let's see if everything got initialized properly
		// by calling various display methods!
		
		System.out.println("====================");
		System.out.println("Course Catalog:");
		System.out.println("====================");
		System.out.println("");
		courseCatalog.display();

		System.out.println("====================");
		System.out.println("Schedule of Classes:");
		System.out.println("====================");
		System.out.println("");
		scheduleOfClasses.display();

		System.out.println("======================");
		System.out.println("Professor Information:");
		System.out.println("======================");
		System.out.println("");
		faculty.display();

		System.out.println("====================");
		System.out.println("Student Information:");
		System.out.println("====================");
		System.out.println("");
		s1.display();
		System.out.println("");
		s2.display();
		System.out.println("");
		s3.display();
	}
}
