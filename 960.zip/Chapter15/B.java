// B.java - Chapter 15 example.

// Copyright 2000 by Jacquie Barker - all rights reserved.

import java.io.*;

public class B implements Serializable {
	// A "B" object holds onto a reference to a "C" object.
	private C sea;

	public void setC(C aSea) {
		sea = aSea;
	}

	public C getC() {
		return sea;
	}
}
