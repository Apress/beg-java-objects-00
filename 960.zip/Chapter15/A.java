// A.java - Chapter 15 example.

// Copyright 2000 by Jacquie Barker - all rights reserved.

import java.io.*;

public class A implements Serializable {
	// An "A" object holds onto a reference to a "B" object.
	private B bee;

	public void setB(B aBee) {
		bee = aBee;
	}

	public B getB() {
		return bee;
	}
}
