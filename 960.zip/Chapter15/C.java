// C.java - Chapter 15 example.

// Copyright 2000 by Jacquie Barker - all rights reserved.

import java.io.*;

public class C implements Serializable {
	// To complete the loop, a "C" object holds onto a reference to 
	// an "A" object.
	private A aaa;

	public void setA(A anA) {
		aaa = anA;
	}

	public A getA() {
		return aaa;
	}
}
