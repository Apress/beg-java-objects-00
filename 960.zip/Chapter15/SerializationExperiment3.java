// SerializationExperiment3.java - Chapter 15 example.

// Copyright 2000 by Jacquie Barker - all rights reserved.

import java.io.*;

public class SerializationExperiment3 {
	public static void main(String[] args) {

		// Create three objects -- an A, a B, and a C.

		A a = new A();
		B b = new B();
		C c = new C();

		// Have them hold onto one another in a cyclical
		// fashion.

		a.setB(b);
		b.setC(c);
		c.setA(a);

		// Serialize the A object (and, automatically, the
		// chained B and C objects go along for the ride!) to 
		// a file ...

		try {
			ObjectOutputStream oos = new ObjectOutputStream(
			 	new FileOutputStream("A.dat"));

			oos.writeObject(a);
			oos.close();

			a = null;

			ObjectInputStream ois = new ObjectInputStream(
				new FileInputStream("A.dat"));
			a = (A) ois.readObject();
			ois.close();
		}
		catch (Exception e) { }

		// Make sure that the objects are all there.
		if (a == null) System.out.println("BUMMER ... a is null!");
		else {
			b = a.getB();
			if (b == null) System.out.println("BUMMER ... b is null!");
			else {
				c = b.getC();
				if (c == null) System.out.println("BUMMER ... c is null!");
				else System.out.println("HOORAY!");
			}
		}
	}
}
