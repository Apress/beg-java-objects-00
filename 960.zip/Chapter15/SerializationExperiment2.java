// SerializationExperiment2.java - Chapter 15 example.

// Copyright 2000 by Jacquie Barker - all rights reserved.

import java.io.*;

public class SerializationExperiment2 {
	public static void main(String[] args) {

		// Create a "Y" object.

		Y y = new Y("I'm a Why!");

		// Encapsulate the same "Y" object in two different
		// "X" objects.

		X x1 = new X(y);
		X x2 = new X(y);

		// Serialize both X's (and, automatically, their embedded Y's
		// go along for the ride!) to a file ...

		try {
			ObjectOutputStream oos = new ObjectOutputStream(
			 	new FileOutputStream("XY.dat"));

			oos.writeObject(x1);
			oos.writeObject(x2);
			oos.close();

			x1 = null;
			x2 = null;

			ObjectInputStream ois = new ObjectInputStream(
				new FileInputStream("XY.dat"));
			x1 = (X) ois.readObject();
			x2 = (X) ois.readObject();
			ois.close();
		}
		catch (Exception e) { }

		// See if the two embedded "Y's" are the same object,
		// or clones of one another!

		Y firstYHandle = x1.getY();
		Y secondYHandle = x2.getY();

		if (firstYHandle == secondYHandle) 
			System.out.println("They are the same object!");
		else {
			System.out.println("They are different objects ...");
			System.out.println("Name of first Y:  " + 
					   firstYHandle.getName());
			System.out.println("Name of second Y:  " + 
					   secondYHandle.getName());
			if (firstYHandle.getName().equals(
				secondYHandle.getName())) {
				System.out.println("They are clones of one another!");
			}
		}
	}
}
