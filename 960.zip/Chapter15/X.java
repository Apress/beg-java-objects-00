// X.java - Chapter 15 example.

// Copyright 2000 by Jacquie Barker - all rights reserved.

import java.io.*;

class X implements Serializable {
	// An "X" object holds onto a reference to a "Y" object.
	private Y why;

	// Constructor.
	
	public X(Y aWhy) {
		why = aWhy;
	}

	public Y getY() {
		return why;
	}
}
