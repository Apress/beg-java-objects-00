// Y.java - Chapter 15 example.

// Copyright 2000 by Jacquie Barker - all rights reserved.

import java.io.*;

class Y implements Serializable {
	private String name;

	// Constructor.

	public Y(String n) {
		name = n;
	}

	public String getName() {
		return name;
	}
}
