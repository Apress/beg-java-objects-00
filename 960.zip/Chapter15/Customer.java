// Customer.java - Chapter 15 example.

// Copyright 2000 by Jacquie Barker - all rights reserved.

import java.io.*;

class Customer implements Serializable {
	String ssn;
	String name;
	String cityAndState;

	// Constructor.

	public Customer(String s, String n, String cs) {
		ssn = s;
		name = n;
		cityAndState = cs;
	}

	public String getName() {
		return name;
	}
}
