// SerializationExperiment.java - Chapter 15 example.

// Copyright 2000 by Jacquie Barker - all rights reserved.

import java.io.*;

public class SerializationExperiment {
    public static void main(String args[]) {
	Customer cl = null;
	Customer c2 = null;

	// For my next feat of magic, I am going to attempt to serialize 
	// and send two customer objects to a file, then read them back out 
	// again.

	try {
		// Create the two objects.

		cl = new Customer ("111-22-3333", "Jeff Goldblum", "Cleveland, Ohio");
		c2 = new Customer("999-88-4444", "Gina Davis", "Cleveland, Ohio");

		// Serialize both objects to the same file.

		ObjectOutputStream oos = new ObjectOutputStream(
				         new FileOutputStream("customers.dat"));
		oos.writeObject(cl);
		oos.writeObject(c2);
		oos.close();

		// Drop the original handles on these two objects, to prove 
		// that this is working!

		cl = null;
		c2 = null;

		// Now, reconstitute the objects (remember to cast!).

		ObjectInputStream ois = new ObjectInputStream(
					new FileInputStream("customers.dat"));
		cl = (Customer) ois.readObject();
		c2 = (Customer) ois.readObject();
		ois.close();

		// Prove that the objects did indeed get recreated.

		System.out.println("Reconstituted " + cl.getName());
		System.out.println("Reconstituted " + c2.getName());
	}
	catch (FileNotFoundException e) { }
	catch (IOException e) { }
	catch (ClassNotFoundException e) { }
    }
}
