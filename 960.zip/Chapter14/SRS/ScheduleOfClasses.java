// ScheduleOfClasses.java - Chapter 14 version.

// Copyright 2000 by Jacquie Barker - all rights reserved.

// A MODEL class.


import java.util.*;

public class ScheduleOfClasses {
	//------------
	// Attributes.
	//------------

	private String semester;

	// This Hashtable stores Section object references, using
	// a String concatenation of course no. and section no. as the
	// key, e.g., "MATH101 - 1".

	private Hashtable sectionsOffered; 

	//----------------
	// Constructor(s).
	//----------------

	public ScheduleOfClasses(String semester) {
		setSemester(semester);
		
		// Instantiate a new Hashtable.

		sectionsOffered = new Hashtable();
	}

	//-----------------
	// Get/set methods.
	//-----------------

	public void setSemester(String semester) {
		this.semester = semester;
	}

	public String getSemester() {
		return semester;
	}

	//-----------------------------
	// Miscellaneous other methods.
	//-----------------------------

	// Used for testing purposes.
	
	public void display() {
		System.out.println("Schedule of Classes for " + getSemester());
		System.out.println("");

		// Step through the Hashtable and display all entries.

		Enumeration e = sectionsOffered.elements();

		while (e.hasMoreElements()) {
			Section s = (Section) e.nextElement();
			s.display();
			System.out.println("");
		}
	}

	public void addSection(Section s) {
		// We formulate a key by concatenating the course no.
		// and section no., separated by a hyphen.

		String key = s.getRepresentedCourse().getCourseNo() + 
			     " - " + s.getSectionNo();
		sectionsOffered.put(key, s);

		// Bidirectionally hook the ScheduleOfClasses back to the Section.

		s.setOfferedIn(this);
	}
}
